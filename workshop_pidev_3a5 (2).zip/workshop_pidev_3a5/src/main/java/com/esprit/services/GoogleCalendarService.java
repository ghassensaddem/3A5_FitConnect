package com.esprit.services;

import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.services.calendar.Calendar;
import com.google.api.services.calendar.CalendarScopes;
import com.google.api.services.calendar.model.Event;
import com.google.api.services.calendar.model.Events;

import java.io.*;
import java.security.GeneralSecurityException;
import java.util.Arrays;
import java.util.List;

public class GoogleCalendarService {
    private static final String APPLICATION_NAME = "Mon Application Calendar";
    private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();
    private static final List<String> SCOPES = Arrays.asList(CalendarScopes.CALENDAR);
    private static final String TOKENS_DIRECTORY_PATH = "tokens";

    private static Credential getCredentials() throws IOException, GeneralSecurityException {
        System.out.println("🔹 Début du processus d'authentification...");

        InputStream credentialsStream = GoogleCalendarService.class.getClassLoader().getResourceAsStream("credentials.json");

        if (credentialsStream == null) {
            System.err.println("❌ ERREUR: Fichier 'credentials.json' non trouvé !");
            throw new FileNotFoundException("Resource file 'credentials.json' not found");
        }
        System.out.println("✅ Fichier credentials.json trouvé avec succès.");

        GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(credentialsStream));
        System.out.println("✅ ClientSecrets chargé avec succès.");

        // Création du flux d'autorisation
        System.out.println("🔹 Création du flux d'autorisation...");
        GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(
                GoogleNetHttpTransport.newTrustedTransport(), JSON_FACTORY, clientSecrets, SCOPES)
                .setDataStoreFactory(new FileDataStoreFactory(new File(TOKENS_DIRECTORY_PATH)))
                .setAccessType("offline")
                .build();
        System.out.println("✅ Flux d'autorisation créé avec succès.");

        // Lancement du processus d'autorisation
        System.out.println("🔹 Lancement de l'autorisation via le navigateur...");
        Credential credential = new AuthorizationCodeInstalledApp(flow, new LocalServerReceiver()).authorize("user");
        System.out.println("✅ Utilisateur authentifié avec succès.");

        return credential;
    }

    public static List<Event> getCalendarEvents() throws IOException, GeneralSecurityException {
        System.out.println("🔹 Début de la récupération des événements du calendrier...");

        // Authentification
        Credential credential = getCredentials();
        System.out.println("✅ Authentification réussie.");

        // Création du service Google Calendar
        System.out.println("🔹 Connexion à l'API Google Calendar...");
        Calendar service = new Calendar.Builder(GoogleNetHttpTransport.newTrustedTransport(), JSON_FACTORY, credential)
                .setApplicationName(APPLICATION_NAME)
                .build();
        System.out.println("✅ Connexion à Google Calendar réussie.");

        // Récupération des événements
        System.out.println("🔹 Récupération des 10 prochains événements du calendrier...");
        Events events = service.events().list("primary")
                .setMaxResults(10)
                .setOrderBy("startTime")
                .setSingleEvents(true)
                .execute();

        List<Event> items = events.getItems();
        System.out.println("✅ Événements récupérés avec succès (" + items.size() + " événements trouvés).");

        // Affichage des événements pour vérifier leur contenu
        if (items.isEmpty()) {
            System.out.println("ℹ️ Aucun événement trouvé.");
        } else {
            for (Event event : items) {
                System.out.println("📅 Événement: " + event.getSummary() +
                        " | Date: " + (event.getStart().getDateTime() != null ? event.getStart().getDateTime() : event.getStart().getDate()));
            }
        }

        return items;
    }

    public static void main(String[] args) {
        try {
            System.out.println("🔹 Lancement du programme...");
            List<Event> events = getCalendarEvents();
            System.out.println("✅ Programme terminé avec succès !");
        } catch (IOException | GeneralSecurityException e) {
            System.err.println("❌ ERREUR: Une exception s'est produite.");
            e.printStackTrace();
        }
    }
}

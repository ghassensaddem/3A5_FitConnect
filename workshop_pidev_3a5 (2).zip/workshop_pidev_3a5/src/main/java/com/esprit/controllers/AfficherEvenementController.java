package com.esprit.controllers;

import com.esprit.services.GoogleCalendarService;
import com.google.api.services.calendar.model.Event;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.List;

public class AfficherEvenementController {

    @FXML
    private TableView<Event> eventsTable;

    @FXML
    private TableColumn<Event, String> colEventSummary;

    @FXML
    private TableColumn<Event, String> colEventStartTime;

    @FXML
    private TableColumn<Event, String> colEventEndTime;

    private final GoogleCalendarService calendarService = new GoogleCalendarService();

    @FXML
    public void initialize() {
        // Associer les colonnes aux propriétés de l'objet Event
        colEventSummary.setCellValueFactory(new PropertyValueFactory<>("summary"));
        colEventStartTime.setCellValueFactory(new PropertyValueFactory<>("start"));
        colEventEndTime.setCellValueFactory(new PropertyValueFactory<>("end"));

        // Charger les événements au démarrage
        loadCalendarEvents();
    }

    @FXML
    private void loadCalendarEvents() {
        try {
            List<Event> events = calendarService.getCalendarEvents();
            ObservableList<Event> observableEvents = FXCollections.observableArrayList(events);
            eventsTable.setItems(observableEvents);
        } catch (IOException | GeneralSecurityException e) {
            e.printStackTrace(); // Affiche l'erreur en console
        }
    }
}

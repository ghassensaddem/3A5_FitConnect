package com.esprit.controllers;

import com.esprit.models.EventModel;
import com.esprit.services.GoogleCalendarService;
import com.google.api.services.calendar.model.Event;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class CalendarController {
    @FXML private TableView<EventModel> calendarTable;
    @FXML private TableColumn<EventModel, String> colTitle;
    @FXML private TableColumn<EventModel, String> colDate;

    private final ObservableList<EventModel> eventList = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        colTitle.setCellValueFactory(new PropertyValueFactory<>("title"));
        colDate.setCellValueFactory(new PropertyValueFactory<>("startTime"));

        try {
            List<Event> events = GoogleCalendarService.getCalendarEvents();
            for (Event event : events) {
                String title = event.getSummary();
                String startTime = event.getStart().getDateTime() != null
                        ? formatDate(event.getStart().getDateTime().toStringRfc3339())
                        : "No Start Time";

                eventList.add(new EventModel(title, startTime));
            }
            calendarTable.setItems(eventList);
        } catch (IOException | GeneralSecurityException e) {
            e.printStackTrace();
        }
    }

    private String formatDate(String dateTime) {
        Instant instant = Instant.parse(dateTime);
        return DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")
                .withZone(ZoneId.systemDefault())
                .format(instant);
    }
}
